const axios = require('axios');
require('dotenv').config();

const API_KEY = process.env.WEATHER_API_KEY;
const CITY = 'Kyiv';
const getWeather = async(city) => {
    const response = await axios.get('https://api.openweathermap.org/data/2.5/weather', {
        params: {
            q: city,
            appid: API_KEY,
            units: 'metric', // Температура в Цельсіях
        },
    });
    return response.data;
};

// Тест 1: Перевірка отримання погоди для конкретного міста
const testWeatherForCity = async(city) => {
    const weatherData = await getWeather(city);
    console.log(`Test 1: Weather for ${city}`);
    console.log(`Temperature: ${weatherData.main.temp}°C`);
    console.log(`Weather: ${weatherData.weather[0].description}`);
    console.log(`Humidity: ${weatherData.main.humidity}%`);
    console.log(`Wind Speed: ${weatherData.wind.speed} m/s`);
};

// Тест 2: Перевірка формату температури в Цельсіях
const testTemperatureInCelsius = async() => {
    const weatherData = await getWeather(CITY);
    const temperature = weatherData.main.temp;
    console.log(`Test 2: Temperature format in Celsius`);
    console.log(`Temperature: ${temperature}°C`);
    if (temperature < -50 || temperature > 50) {
        console.error('Error: Temperature is out of expected range.');
    } else {
        console.log('Temperature is within expected range.');
    }
};

// Тест 3: Перевірка наявності обов'язкових полів в відповіді
const testRequiredFields = async() => {
    const weatherData = await getWeather(CITY);
    console.log(`Test 3: Check required fields`);
    if (weatherData.main.humidity !== undefined && weatherData.wind.speed !== undefined) {
        console.log('All required fields are present.');
    } else {
        console.error('Error: Missing required fields.');
    }
};

// Запуск тестів
const runTests = async() => {
    await testWeatherForCity(CITY);
    await testTemperatureInCelsius();
    await testRequiredFields();
};

runTests();