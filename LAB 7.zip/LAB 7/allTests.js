const axios = require('axios');
require('dotenv').config();
const { expect } = require('chai');

// Параметри
const API_KEY = process.env.WEATHER_API_KEY;
const CITY = 'Kyiv';

// Функція для отримання погодних даних
const getWeather = async(city) => {
    const response = await axios.get('https://api.openweathermap.org/data/2.5/weather', {
        params: {
            q: city,
            appid: API_KEY,
            units: 'metric',
        },
    });
    return response.data;
};

// --------- API Тести ---------
// Тест 1: Перевірка отримання погоди
const testWeatherForCity = async(city) => {
    const weatherData = await getWeather(city);
    console.log(`Test 1: Weather for ${city}`);
    console.log(`Temperature: ${weatherData.main.temp}°C`);
};

// Тест 2: Перевірка температури в Цельсіях
const testTemperatureInCelsius = async() => {
    const weatherData = await getWeather(CITY);
    const temperature = weatherData.main.temp;
    console.log(`Test 2: Temperature format in Celsius`);
    if (temperature < -50 || temperature > 50) {
        console.error('Error: Temperature is out of expected range.');
    }
};

// Тест 3: Перевірка наявності обов'язкових полів
const testRequiredFields = async() => {
    const weatherData = await getWeather(CITY);
    console.log(`Test 3: Check required fields`);
    if (weatherData.main.humidity !== undefined && weatherData.wind.speed !== undefined) {
        console.log('All required fields are present.');
    } else {
        console.error('Error: Missing required fields.');
    }
};

// Тест 4: Перевірка статусу відповіді
const testResponseStatus = async() => {
    try {
        const response = await axios.get('https://api.openweathermap.org/data/2.5/weather', {
            params: {
                q: CITY,
                appid: API_KEY,
                units: 'metric',
            },
        });
        console.log(`Test 4: Status Code: ${response.status}`);
        if (response.status !== 200) {
            console.error('Error: Unexpected status code');
        }
    } catch (error) {
        console.error('Error:', error);
    }
};

// Тест 5: Перевірка наявності координат
const testCoordinates = async() => {
    const weatherData = await getWeather(CITY);
    console.log(`Test 5: Check coordinates`);
    if (weatherData.coord.lat !== undefined && weatherData.coord.lon !== undefined) {
        console.log('Coordinates are present.');
    } else {
        console.error('Error: Missing coordinates');
    }
};

// --------- Unit Тести ---------
// Функція для перевірки температури
const isTemperatureValid = (temp) => temp >= -50 && temp <= 50;

describe('Unit Tests for Weather Data Processing', () => {
    it('should validate temperature range', () => {
        const validTemp = 25;
        const invalidTemp = 60;
        expect(isTemperatureValid(validTemp)).to.be.true;
        expect(isTemperatureValid(invalidTemp)).to.be.false;
    });
});

// --------- UI Тести (Cypress) ---------
// UI тести зазвичай працюють через Cypress, тому їх треба запускати окремо
describe('UI Tests for Weather Page', () => {
    it('should display temperature correctly', () => {
        cy.visit('https://example.com'); // Заміни на реальний URL
        cy.get('.temperature').should('contain', '°C');
    });

    it('should display weather description', () => {
        cy.visit('https://example.com');
        cy.get('.weather-description').should('not.be.empty');
    });

    it('should be responsive on mobile', () => {
        cy.viewport('iphone-6');
        cy.visit('https://example.com');
        cy.get('.weather-container').should('be.visible');
    });
});

// --------- E2E Тести (Cypress) ---------
describe('E2E Tests for Weather Site', () => {
    it('should allow the user to search for weather by city', () => {
        cy.visit('https://example.com');
        cy.get('.city-input').type('Kyiv');
        cy.get('.submit-button').click();
        cy.get('.temperature').should('not.be.empty');
    });

    it('should display correct weather details after search', () => {
        cy.visit('https://example.com');
        cy.get('.city-input').type('Kyiv');
        cy.get('.submit-button').click();
        cy.get('.weather-description').should('contain', 'clear sky');
    });
});

// Запуск API тестів
const runTests = async() => {
    await testWeatherForCity(CITY);
    await testTemperatureInCelsius();
    await testRequiredFields();
    await testResponseStatus();
    await testCoordinates();
};

runTests();