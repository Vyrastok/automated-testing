describe('E2E Tests for Weather Site', () => {
    it('should allow the user to search for weather by city', () => {
        cy.visit('https://example.com');
        cy.get('.city-input').type('Kyiv');
        cy.get('.submit-button').click();
        cy.get('.temperature').should('not.be.empty');
    });

    it('should display correct weather details after search', () => {
        cy.visit('https://example.com');
        cy.get('.city-input').type('Kyiv');
        cy.get('.submit-button').click();
        cy.get('.weather-description').should('contain', 'clear sky');
    });
});