const { expect } = require('chai');

// Функція для перевірки температури
const isTemperatureValid = (temp) => temp >= -50 && temp <= 50;

describe('Unit Tests for Weather Data Processing', () => {
    it('should validate temperature range', () => {
        const validTemp = 25;
        const invalidTemp = 60;
        expect(isTemperatureValid(validTemp)).to.be.true;
        expect(isTemperatureValid(invalidTemp)).to.be.false;
    });
});