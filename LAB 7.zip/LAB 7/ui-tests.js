describe('UI Tests for Weather Page', () => {
    it('should display temperature correctly', () => {
        cy.visit('https://example.com');
        cy.get('.temperature').should('contain', '°C');
    });

    it('should display weather description', () => {
        cy.visit('https://example.com');
        cy.get('.weather-description').should('not.be.empty');
    });

    it('should be responsive on mobile', () => {
        cy.viewport('iphone-6');
        cy.visit('https://example.com');
        cy.get('.weather-container').should('be.visible');
    });
});