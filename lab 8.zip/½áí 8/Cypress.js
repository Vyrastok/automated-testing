// Для Cypress
describe('UI Test 1: Temperature Display', () => {
    it('should display the temperature correctly', () => {
        cy.visit('https://openweathermap.org/');
        cy.get('.temperature').should('contain', '°C');
    });
});

describe('UI Test 2: Weather Description', () => {
    it('should display the weather description', () => {
        cy.visit('https://openweathermap.org/');
        cy.get('.weather-description').should('not.be.empty');
    });
});

describe('UI Test 3: Responsiveness on Mobile', () => {
    it('should be responsive on mobile', () => {
        cy.viewport('iphone-6');
        cy.visit('https://openweathermap.org/');
        cy.get('.weather-container').should('be.visible');
    });
});