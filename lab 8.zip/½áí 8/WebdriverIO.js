// Тести для WebdriverIO
describe('UI Test 1: Temperature Display', () => {
    it('should display the temperature correctly', async() => {
        await browser.url('https://openweathermap.org/');
        const temperature = await $('.temperature');
        expect(await temperature.getText()).toContain('°C');
    });
});

describe('UI Test 2: Weather Description', () => {
    it('should display the weather description', async() => {
        await browser.url('https://openweathermap.org/');
        const weatherDescription = await $('.weather-description');
        expect(await weatherDescription.getText()).not.toBe('');
    });
});

describe('UI Test 3: Responsiveness on Mobile', () => {
    it('should be responsive on mobile', async() => {
        await browser.url('https://openweathermap.org/');
        await browser.setWindowSize(375, 667);
        const weatherContainer = await $('.weather-container');
        expect(await weatherContainer.isDisplayed()).toBe(true);
    });
});