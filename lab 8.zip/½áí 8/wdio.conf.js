exports.config = {
    runner: 'local',
    framework: 'mocha',
    reporters: ['dot'],
    capabilities: [{
        browserName: 'chrome',
        maxInstances: 1
    }],
    logLevel: 'info',
    baseUrl: 'https://openweathermap.org/',
    waitforTimeout: 10000,
    mochaOpts: {
        ui: 'bdd',
        timeout: 60000
    },
    services: ['chromedriver'],
};