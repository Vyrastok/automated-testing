Cypress.Commands.add('login', (username, password) => {
    cy.get('.login-button').click();
    cy.get('input[name="username"]').type(username);
    cy.get('input[name="password"]').type(password);
    cy.get('.submit-button').click();
});