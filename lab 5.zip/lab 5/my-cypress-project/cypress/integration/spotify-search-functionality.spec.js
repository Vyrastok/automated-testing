describe('Перевірка функціональності пошуку пісень', () => {
    it('Пошук пісні за ключовими словами', () => {
        // Відкриваємо додаток
        cy.visit('https://www.spotify.com');

        // Ввести в пошук назву пісні
        cy.get('.search-bar').type('Blinding Lights');

        // Перевіряємо, чи з'явились результати пошуку
        cy.get('.search-results').should('contain', 'Blinding Lights');
    });
});