describe('Перевірка кнопки "Додати в бібліотеку"', () => {
    it('Пісня повинна додаватись у бібліотеку після натискання кнопки', () => {
        // Відкриваємо додаток
        cy.visit('https://www.spotify.com');

        // Авторизуємося (потрібно додати коректні дані)
        cy.get('.login-button').click();
        cy.get('input[name="username"]').type('your-username');
        cy.get('input[name="password"]').type('your-password');
        cy.get('.submit-button').click();

        // Перейти на пісню
        cy.get('.song').first().click();

        // Натискаємо "Додати в бібліотеку"
        cy.get('.add-to-library-button').click();

        // Перевіряємо, чи пісня з'явилась у бібліотеці
        cy.get('.library').should('contain', 'your-song-name');
    });
});